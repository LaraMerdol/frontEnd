package com.project.cs319.Controller;
import com.project.cs319.Entity.*;
import com.project.cs319.DataBase.*;
import com.mongodb.client.MongoCollection;
import org.bson.Document;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import org.json.JSONArray;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/GroupFormationController")
public class GroupFormationController {
    private  mongoDB database;
    private ArrayList<User> membersOfGroup;

    public GroupFormationController(){
        database = new mongoDB();
    }

    @GetMapping("/randomGenerator")
    public  String randomGenerator(int size, int sectionID) {
        database = new mongoDB();
        int numberOfStudent = database.getNumberOfStudentsFromSection(sectionID);
        int groupSize = size;

        ArrayList<Integer> idOfStudentsInSection = database.getAllStudentsIdFromSection(sectionID);

        Collections.shuffle(idOfStudentsInSection, new Random());

        char groupName = 'a';
        int index =0;
        for (int i = 0; i < (Integer) (numberOfStudent / groupSize); i++, groupName++) {
            String groupID = "CS319-" + sectionID + groupName;

            // database
            database.createGroup(groupID);
            for (int whileIndex = 0; whileIndex < groupSize; whileIndex++, index++) {
                database.insertStudentToGroup(groupID, idOfStudentsInSection.get(whileIndex + groupSize * i), sectionID);
            }
        }
        if(index == numberOfStudent)
        {
            return null;
        }
        ArrayList<Integer> remainStudents = new ArrayList<Integer>();
        for(int i = index;  i < numberOfStudent; i++)
        {
            remainStudents.add(idOfStudentsInSection.get(i));
        }
        return (new JSONArray(remainStudents)).toString();
    }

    @GetMapping("/notRandomGenerator")
    public void notRandomGenerator(int sectionID, int studentID)
    {
        database = new mongoDB();
        database.createGroupByUser(sectionID,studentID);
    }

    @GetMapping("/notRandomGeneratorAddMember")
    public void notRandomGeneratorAddMember(int studentID, String groupName,int sectionID) {
        database = new mongoDB();
        database.insertStudentToGroup(groupName,studentID,sectionID);
    }

    @GetMapping("/removeUserFromGroup")
    public boolean removeUserFromGroup(int studentID) {
        database = new mongoDB();
        return database.removeUserFromGroup(studentID);
    }


}
