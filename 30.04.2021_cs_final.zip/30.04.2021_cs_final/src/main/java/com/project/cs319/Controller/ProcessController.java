package com.project.cs319.Controller;

import com.project.cs319.DataBase.mongoDB;

public class ProcessController
{
    public static mongoDB database;

    public ProcessController()
    {
        database = new mongoDB();
    }
    public String isGroupFormationOnOrOff()
    {
        return database.isGroupFormationONOrOff("process");
    }

    public String isPeerReviewON()
    {
        return database.isPeerReviewOnOrOff("process");
    }

    public String isCourseReviewON()
    {
        return database.isCourseReviewOnOrOff("process");
    }

    public String isProjectRatingOnOrOff()
    {
        return database.isProjectRatingOnOrOff("process");
    }

    public void changeGroupFormation(String status)
    {
        database.changeGroupFormation(status);
    }

    public void changePeerReview(String status)
    {
        database.changePeerReview(status);
    }

    public void changeCourseReview(String status)
    {
        database.changeCourseReview(status);
    }

    public void changeProjectRating(String status)
    {
        database.changeProjectRating(status);
    }
}
