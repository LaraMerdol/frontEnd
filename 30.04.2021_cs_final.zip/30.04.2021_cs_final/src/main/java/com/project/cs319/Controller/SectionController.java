package com.project.cs319.Controller;
import com.project.cs319.Entity.*;
import com.project.cs319.DataBase.*;

import java.util.ArrayList;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/SectionController")
public class SectionController {
    private  mongoDB database;

    public SectionController(){ database = new mongoDB();}

    @GetMapping("/addSection")
    public boolean addSection(int sectionNumber, int instructorID)
    {
        database = new mongoDB();
        return database.createSection(sectionNumber, instructorID);
    }

    @GetMapping("/addUserToSection")
    public boolean addUserToSection(int schoolID, int sectionNumber, String userRole)
    {
        database = new mongoDB();
        return database.insertUserToSection(schoolID, sectionNumber, userRole);
    }

}
