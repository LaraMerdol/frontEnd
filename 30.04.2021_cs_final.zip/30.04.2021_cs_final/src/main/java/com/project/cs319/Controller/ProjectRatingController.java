package com.project.cs319.Controller;
import com.project.cs319.DataBase.mongoDB;

public class ProjectRatingController {

    private mongoDB database;

    public ProjectRatingController()
    {
        database = new mongoDB();
    }

    public void giveRateToProject(String groupName, int rate)
    {
        database.giveRateToProject(groupName, rate);
    }

    public double getRateOfProject(String groupName)
    {
        return database.getRateOfProject(groupName);
    }
}
